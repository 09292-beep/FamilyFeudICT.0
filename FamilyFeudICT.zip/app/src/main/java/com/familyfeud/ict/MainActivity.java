package com.familyfeud.ict;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(7,26,61);
    private final int blue = Color.rgb(20,76,145);
    private final int gold = Color.rgb(245,197,66);
    private LinearLayout root;
    private TextView scoreView, questionView, statusView;
    private EditText answerInput;
    private int score = 0, qIndex = 0, misses = 0;
    private String difficulty = "Easy";
    private ArrayList<Question> questions = new ArrayList<>();
    private HashSet<Integer> found = new HashSet<>();

    static class Question {
        String prompt;
        String[] answers;
        int points;
        Question(String p, String[] a, int pts) { prompt=p; answers=a; points=pts; }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        showHome();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12,12,12,12);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        b.setAllCaps(false);
        return b;
    }

    private void setup(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(18,18,18,18);
        root.setBackgroundColor(navy);
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);
        root.addView(text(title, 28, gold, true));
    }

    private void showHome() {
        setup("FAMILY FEUD ICT");
        root.addView(text("Guess the most common answers!", 17, Color.WHITE, false));
        Button play = button("▶  Start Game");
        root.addView(play);
        play.setOnClickListener(v -> chooseDifficulty());
        Button scores = button("🏆  Leaderboard");
        root.addView(scores);
        scores.setOnClickListener(v -> showLeaderboard());
        root.addView(text("Offline game • ICT questions • 1–3 points", 14, Color.LTGRAY, false));
    }

    private void chooseDifficulty() {
        new AlertDialog.Builder(this).setTitle("Choose difficulty")
          .setItems(new String[]{"Easy","Medium","Hard"}, (d,which) -> {
              difficulty = new String[]{"Easy","Medium","Hard"}[which];
              startGame();
          }).show();
    }

    private void startGame() {
        questions = questionBank(difficulty);
        Collections.shuffle(questions);
        qIndex=0; score=0; misses=0; found.clear();
        showQuestion();
    }

    private ArrayList<Question> questionBank(String level) {
        ArrayList<Question> list = new ArrayList<>();
        int pts = level.equals("Easy") ? 1 : level.equals("Medium") ? 2 : 3;
        if (level.equals("Easy")) {
            list.add(new Question("Name something you use to type on a computer.", new String[]{"KEYBOARD","KEYS"},pts));
            list.add(new Question("Name a device used to print documents.", new String[]{"PRINTER"},pts));
            list.add(new Question("Name an app used to browse the internet.", new String[]{"CHROME","BROWSER","FIREFOX","EDGE"},pts));
            list.add(new Question("Name a common computer pointing device.", new String[]{"MOUSE"},pts));
            list.add(new Question("Name something used to save files.", new String[]{"USB","FLASH DRIVE","HARD DRIVE","SSD"},pts));
        } else if (level.equals("Medium")) {
            list.add(new Question("Name a type of computer network.", new String[]{"LAN","WAN","MAN"},pts));
            list.add(new Question("Name a file format commonly used for documents.", new String[]{"PDF","DOCX","DOC"},pts));
            list.add(new Question("Name a device that connects a network to the internet.", new String[]{"ROUTER","MODEM"},pts));
            list.add(new Question("Name a program used to make presentations.", new String[]{"POWERPOINT","GOOGLE SLIDES","KEYNOTE"},pts));
            list.add(new Question("Name a computer component that stores data long-term.", new String[]{"HARD DRIVE","HDD","SSD"},pts));
        } else {
            list.add(new Question("Name a cybersecurity practice that protects accounts.", new String[]{"TWO FACTOR AUTHENTICATION","2FA","MFA","STRONG PASSWORD"},pts));
            list.add(new Question("Name a language used to create web pages.", new String[]{"HTML","JAVASCRIPT","CSS"},pts));
            list.add(new Question("Name a cloud storage service.", new String[]{"GOOGLE DRIVE","ONEDRIVE","DROPBOX","ICLOUD"},pts));
            list.add(new Question("Name a protocol used to secure websites.", new String[]{"HTTPS","TLS","SSL"},pts));
            list.add(new Question("Name a database management system.", new String[]{"MYSQL","ORACLE","SQL SERVER","POSTGRESQL"},pts));
        }
        return list;
    }

    private void showQuestion() {
        setup("FAMILY FEUD ICT");
        if (qIndex >= questions.size()) { finishGame(); return; }
        Question q = questions.get(qIndex);
        scoreView = text("SCORE: " + score + "     " + difficulty.toUpperCase(), 18, gold, true);
        root.addView(scoreView);
        questionView = text((qIndex+1) + " / " + questions.size() + "\\n" + q.prompt, 21, Color.WHITE, true);
        root.addView(questionView);
        statusView = text("Find the answer!  " + found.size() + " found", 15, Color.LTGRAY, false);
        root.addView(statusView);
        answerInput = new EditText(this);
        answerInput.setSingleLine(true);
        answerInput.setHint("Type your answer");
        answerInput.setTextColor(Color.WHITE);
        answerInput.setHintTextColor(Color.LTGRAY);
        root.addView(answerInput);
        Button submit = button("Submit Answer");
        root.addView(submit);
        submit.setOnClickListener(v -> submitAnswer());
        Button reveal = button("Show Answers");
        root.addView(reveal);
        reveal.setOnClickListener(v -> revealAnswers());
        Button next = button("Next Question");
        root.addView(next);
        next.setOnClickListener(v -> { qIndex++; found.clear(); misses=0; showQuestion(); });
        Button home = button("Home");
        root.addView(home);
        home.setOnClickListener(v -> showHome());
    }

    private String normalize(String s) {
        return s.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9 ]","").trim().replaceAll("\\\\s+"," ");
    }

    private void submitAnswer() {
        Question q = questions.get(qIndex);
        String answer = normalize(answerInput.getText().toString());
        if (answer.isEmpty()) { statusView.setText("Please type an answer."); return; }
        boolean match = false;
        for (int i=0;i<q.answers.length;i++) {
            if (normalize(q.answers[i]).equals(answer)) {
                match=true;
                if (!found.contains(i)) {
                    found.add(i); score += q.points;
                    statusView.setText("Correct! +" + q.points + " point(s).");
                } else statusView.setText("You already found that answer!");
                break;
            }
        }
        if (!match) {
            misses++;
            statusView.setText("Not on the board. Try again! (" + misses + " miss(es))");
        }
        scoreView.setText("SCORE: " + score + "     " + difficulty.toUpperCase());
        answerInput.setText("");
    }

    private void revealAnswers() {
        Question q = questions.get(qIndex);
        StringBuilder sb = new StringBuilder("Answers:\\n");
        for (String a : q.answers) sb.append("• ").append(a).append("\\n");
        new AlertDialog.Builder(this).setTitle("Answer Board").setMessage(sb.toString())
          .setPositiveButton("OK",null).show();
    }

    private void finishGame() {
        saveScore();
        setup("GAME FINISHED!");
        root.addView(text("Your score: " + score, 26, gold, true));
        Button again = button("Play Again");
        root.addView(again); again.setOnClickListener(v -> chooseDifficulty());
        Button home = button("Home");
        root.addView(home); home.setOnClickListener(v -> showHome());
        Button board = button("Leaderboard");
        root.addView(board); board.setOnClickListener(v -> showLeaderboard());
    }

    private void saveScore() {
        android.content.SharedPreferences p = getSharedPreferences("scores", MODE_PRIVATE);
        String name = "Player";
        JSONArray arr;
        try { arr = new JSONArray(p.getString("list","[]")); } catch(Exception e) { arr = new JSONArray(); }
        JSONObject obj = new JSONObject();
        try {
            obj.put("name",name); obj.put("score",score); obj.put("difficulty",difficulty);
            arr.put(obj);
        } catch(Exception ignored) {}
        p.edit().putString("list",arr.toString()).apply();
    }

    private void showLeaderboard() {
        setup("LEADERBOARD");
        android.content.SharedPreferences p = getSharedPreferences("scores", MODE_PRIVATE);
        JSONArray arr;
        try { arr = new JSONArray(p.getString("list","[]")); } catch(Exception e) { arr = new JSONArray(); }
        ArrayList<JSONObject> rows = new ArrayList<>();
        for(int i=0;i<arr.length();i++) try { rows.add(arr.getJSONObject(i)); } catch(Exception ignored) {}
        Collections.sort(rows,(a,b)->b.optInt("score")-a.optInt("score"));
        if(rows.isEmpty()) root.addView(text("No scores yet. Play a game first!",17,Color.WHITE,false));
        for(int i=0;i<Math.min(10,rows.size());i++) {
            JSONObject r=rows.get(i);
            root.addView(text((i+1)+". "+r.optString("name")+" — "+r.optInt("score")+" ("+r.optString("difficulty")+")",17,Color.WHITE,false));
        }
        Button back=button("Home"); root.addView(back); back.setOnClickListener(v->showHome());
    }
}
